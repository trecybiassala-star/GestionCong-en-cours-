<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['RH']);
$repo = repo(); $roles = $repo->roles(); $services = $repo->services();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $nom = trim($_POST['nom'] ?? ''); $prenom = trim($_POST['prenom'] ?? ''); $email = trim($_POST['email'] ?? '');
    $pwd = $_POST['motpasse'] ?? ''; $role = (int)($_POST['role'] ?? 0); $svc = (int)($_POST['service'] ?? 0) ?: null;
    if ($nom === '' || $prenom === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) flash('Nom, prénom et e-mail valide obligatoires.', 'error');
    elseif (strlen($pwd) < 8) flash('Le mot de passe doit contenir au moins 8 caractères.', 'error');
    elseif (!in_array($role, array_map('intval', array_column($roles, 'roleid')), true)) flash('Rôle invalide.', 'error');
    elseif ($repo->emailExiste($email)) flash('Cet e-mail est déjà utilisé.', 'error');
    else { $repo->addUser($nom, $prenom, $email, $pwd, $role, $svc); flash("Employé $prenom $nom ajouté."); }
    redirect('liste.php');
}
$users = $repo->users();
layout_top('Gestion des employés', 'employes/liste.php');
?>
<section class="dashboard-panel reveal">
    <h2>Ajouter un employé</h2>
    <form method="POST"><?= csrf_field() ?>
        <div class="form-grid">
            <div class="input-group"><label for="nom">Nom</label><input id="nom" name="nom" required></div>
            <div class="input-group"><label for="prenom">Prénom</label><input id="prenom" name="prenom" required></div>
            <div class="input-group"><label for="email">E-mail</label><input type="email" id="email" name="email" required></div>
            <div class="input-group"><label for="motpasse">Mot de passe initial</label><input type="password" id="motpasse" name="motpasse" minlength="8" required></div>
            <div class="input-group"><label for="role">Rôle</label><select id="role" name="role" required>
                <?php foreach ($roles as $r) { ?><option value="<?= (int)$r['roleid'] ?>"><?= h($r['nomrole']) ?></option><?php } ?></select></div>
            <div class="input-group"><label for="service">Service</label><select id="service" name="service">
                <option value="0">Aucun</option><?php foreach ($services as $s) { ?><option value="<?= (int)$s['serviceid'] ?>"><?= h($s['nomservice']) ?></option><?php } ?></select></div>
        </div>
        <button type="submit">Ajouter</button>
    </form>
</section>
<section class="dashboard-panel reveal">
    <h2>Employés (<?= count($users) ?>)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Nom</th><th>E-mail</th><th>Rôle</th><th>Service</th></tr></thead>
        <tbody><?php foreach ($users as $x) { ?><tr><td><?= h($x['nom'] . ' ' . $x['prenom']) ?></td><td><?= h($x['email']) ?></td><td><?= h($x['nomrole']) ?></td><td><?= h($x['nomservice'] ?? '-') ?></td></tr><?php } ?></tbody>
    </table></div>
</section>
<?php layout_bottom(); ?>
