<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login();
$u = user(); $repo = repo(); $info = $repo->user($u['utilisateurid']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $ancien = $_POST['ancien'] ?? ''; $nouveau = $_POST['nouveau'] ?? ''; $conf = $_POST['confirmation'] ?? '';
    if (!$repo->login($info['email'], $ancien)) flash('Mot de passe actuel incorrect.', 'error');
    elseif (strlen($nouveau) < 8) flash('Le nouveau mot de passe doit contenir au moins 8 caractères.', 'error');
    elseif ($nouveau !== $conf) flash('La confirmation ne correspond pas.', 'error');
    else { $repo->setPassword($u['utilisateurid'], $nouveau); flash('Mot de passe modifié.'); }
    redirect('profil.php');
}
layout_top('Mon profil', 'employes/profil.php');
?>
<div class="profile-container">
<section class="dashboard-panel reveal">
    <h2>Informations</h2>
    <div class="form-grid">
        <div><small>Nom complet</small><p><strong><?= h($info['nom'] . ' ' . $info['prenom']) ?></strong></p></div>
        <div><small>E-mail</small><p><strong><?= h($info['email']) ?></strong></p></div>
        <div><small>Rôle</small><p><strong><?= h($info['nomrole']) ?></strong></p></div>
        <div><small>Service</small><p><strong><?= h($info['nomservice'] ?? '-') ?></strong></p></div>
    </div>
</section>
<section class="dashboard-panel reveal">
    <h2>Changer mon mot de passe</h2>
    <form method="POST"><?= csrf_field() ?>
        <div class="form-grid">
            <div class="input-group"><label for="ancien">Mot de passe actuel</label><input type="password" id="ancien" name="ancien" required></div>
            <div class="input-group"><label for="nouveau">Nouveau mot de passe</label><input type="password" id="nouveau" name="nouveau" minlength="8" required></div>
            <div class="input-group"><label for="confirmation">Confirmation</label><input type="password" id="confirmation" name="confirmation" required></div>
        </div>
        <button type="submit">Mettre à jour</button>
    </form>
</section>
</div>
<?php layout_bottom(); ?>
