<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['RH']);
$repo = repo(); $st = $repo->statuts();
$types = $repo->rapportTypes(); $services = $repo->rapportServices();
layout_top('Rapports', 'rapports/rapport.php');
?>
<div class="statistics">
    <div class="stat-card"><h3>Total des demandes</h3><strong><?= array_sum($st) ?></strong><p>Toutes périodes</p></div>
    <div class="stat-card"><h3>En attente</h3><strong><?= $st['EN_ATTENTE'] ?></strong><p>À traiter</p></div>
    <div class="stat-card"><h3>Approuvées</h3><strong><?= $st['APPROUVEE'] ?></strong><p>Congés accordés</p></div>
    <div class="stat-card"><h3>Refusées</h3><strong><?= $st['REFUSEE'] ?></strong><p>Congés refusés</p></div>
</div>
<section class="dashboard-panel reveal">
    <h2>Jours approuvés par type de congé</h2>
    <div class="table-wrap"><table><thead><tr><th>Type</th><th>Demandes</th><th>Jours</th></tr></thead><tbody>
    <?php foreach ($types as $t) { ?><tr><td><?= h($t['nomtype']) ?></td><td><?= (int)$t['nb'] ?></td><td><?= (int)$t['jours'] ?></td></tr><?php }
    if (!$types) { ?><tr><td colspan="3">Aucune donnée.</td></tr><?php } ?></tbody></table></div>
</section>
<section class="dashboard-panel reveal">
    <h2>Demandes par service</h2>
    <div class="table-wrap"><table><thead><tr><th>Service</th><th>Demandes</th></tr></thead><tbody>
    <?php foreach ($services as $s) { ?><tr><td><?= h($s['nomservice']) ?></td><td><?= (int)$s['nb'] ?></td></tr><?php }
    if (!$services) { ?><tr><td colspan="2">Aucune donnée.</td></tr><?php } ?></tbody></table></div>
</section>
<?php layout_bottom(); ?>
