document.addEventListener("DOMContentLoaded", function () {

    const $  = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
    const reduit = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    /* ==================================================
       OUTILS COMMUNS : messages (toasts), secousse, ripple
    ================================================== */

    function showToast(message, type = "info", duree = 3500) {
        let pile = $(".toast-stack");
        if (!pile) {
            pile = document.createElement("div");
            pile.className = "toast-stack";
            pile.setAttribute("role", "status");
            document.body.appendChild(pile);
        }
        const toast = document.createElement("div");
        toast.className = "toast " + type;
        toast.textContent = message;
        pile.appendChild(toast);
        setTimeout(function () {
            toast.classList.add("out");
            toast.addEventListener("animationend", function () { toast.remove(); }, { once: true });
        }, duree);
    }
    window.showToast = showToast;

    function marquerInvalide(champ) {
        champ.classList.remove("is-invalid");
        void champ.offsetWidth; // relance l'animation
        champ.classList.add("is-invalid");
        champ.addEventListener("input", function () { champ.classList.remove("is-invalid"); }, { once: true });
    }

    document.addEventListener("click", function (e) {
        const b = e.target.closest("button, .btn-validation, .btn-table");
        if (!b || reduit) return;
        const r = b.getBoundingClientRect();
        const t = Math.max(r.width, r.height);
        const o = document.createElement("span");
        o.className = "ripple";
        o.style.cssText = "width:" + t + "px;height:" + t + "px;left:" +
            (e.clientX - r.left - t / 2) + "px;top:" + (e.clientY - r.top - t / 2) + "px";
        b.appendChild(o);
        setTimeout(function () { o.remove(); }, 600);
    });

    /* Messages envoyés par le serveur : index.php?erreur=1  ou  ?succes=Texte */
    const params = new URLSearchParams(window.location.search);
    if (params.get("erreur")) {
        showToast(params.get("erreur") === "1" ? "Identifiants incorrects." : params.get("erreur"), "error", 5000);
    }
    if (params.get("succes")) {
        showToast(params.get("succes") === "1" ? "Opération réussie." : params.get("succes"), "success");
    }

    /* Messages posés par PHP (flash) */
    const flash = $("#flash");
    if (flash) showToast(flash.dataset.msg, flash.dataset.type);

    /* Durée estimée (jours ouvrés) dans le formulaire de demande */
    const dDeb = $("#debut"), dFin = $("#fin"), dDuree = $("#duree");
    if (dDeb && dFin && dDuree) {
        const calc = function () {
            if (!dDeb.value || !dFin.value) { dDuree.textContent = ""; return; }
            let n = 0;
            for (let t = new Date(dDeb.value); t <= new Date(dFin.value); t.setDate(t.getDate() + 1)) {
                if (t.getDay() !== 0 && t.getDay() !== 6) n++;
            }
            dDuree.textContent = dFin.value < dDeb.value ? "La date de fin précède la date de début." : "Durée : " + n + " jour(s) ouvré(s)";
        };
        dDeb.addEventListener("change", function () { dFin.min = dDeb.value; calc(); });
        dFin.addEventListener("change", calc);
        calc();
    }

    /* ==================================================
       PAGE : index.php  (connexion)
    ================================================== */

    const loginForm = $(".login-form");

    if (loginForm) {
        const mdp = $("#password");

        if (mdp) {
            const bascule = document.createElement("button");
            bascule.type = "button";
            bascule.className = "pw-toggle";
            bascule.textContent = "Afficher";
            bascule.setAttribute("aria-label", "Afficher ou masquer le mot de passe");
            bascule.addEventListener("click", function () {
                const visible = mdp.type === "password";
                mdp.type = visible ? "text" : "password";
                bascule.textContent = visible ? "Masquer" : "Afficher";
            });
            mdp.closest(".input-group").appendChild(bascule);
        }

        loginForm.addEventListener("submit", function (event) {
            const vides = $$("input[required]", loginForm).filter(function (i) { return i.value.trim() === ""; });
            if (vides.length) {
                event.preventDefault();
                vides.forEach(marquerInvalide);
                showToast("Veuillez remplir tous les champs de connexion.", "error");
                return;
            }
            $("button[type=submit]", loginForm).classList.add("is-loading");
        });

        window.addEventListener("pageshow", function () {
            const b = $("button[type=submit]", loginForm);
            if (b) b.classList.remove("is-loading");
        });
    }

    /* ==================================================
       PAGE : dashboard.php
    ================================================== */

    if ($(".dashboard-container")) {

        /* Compteurs animés */
        if (!reduit) {
            $$(".stat-card strong").forEach(function (el) {
                const fin = parseInt(el.textContent.replace(/\D/g, ""), 10);
                if (isNaN(fin) || fin === 0) return;
                const debut = performance.now();
                (function pas(t) {
                    const p = Math.min((t - debut) / 1000, 1);
                    el.textContent = Math.round(fin * (1 - Math.pow(1 - p, 3)));
                    if (p < 1) requestAnimationFrame(pas);
                })(debut);
            });
        }

        /* Apparition des blocs au défilement */
        const blocs = $$(".reveal");
        if ("IntersectionObserver" in window) {
            const obs = new IntersectionObserver(function (entrees) {
                entrees.forEach(function (en) {
                    if (en.isIntersecting) { en.target.classList.add("in"); obs.unobserve(en.target); }
                });
            }, { threshold: 0.12 });
            blocs.forEach(function (b) { obs.observe(b); });
        } else {
            blocs.forEach(function (b) { b.classList.add("in"); });
        }

        /* Horloge en direct */
        const horloge = $("#live-clock");
        if (horloge) {
            const maj = function () {
                horloge.textContent = new Date().toLocaleString("fr-FR", {
                    weekday: "long", day: "numeric", month: "long",
                    hour: "2-digit", minute: "2-digit", second: "2-digit"
                });
            };
            maj();
            setInterval(maj, 1000);
        }

        /* Menu mobile */
        const menu = $(".sidebar"), burger = $(".menu-toggle"), voile = $(".sidebar-backdrop");
        if (menu && burger && voile) {
            const basculer = function (ouvert) {
                menu.classList.toggle("open", ouvert);
                voile.classList.toggle("show", ouvert);
            };
            burger.addEventListener("click", function () { basculer(!menu.classList.contains("open")); });
            voile.addEventListener("click", function () { basculer(false); });
        }

        /* Le menu garde sa position de défilement */
        if (menu) {
            const actif = $("a.active", menu);
            const sauve = sessionStorage.getItem("menuScroll");
            if (sauve !== null) menu.scrollTop = parseInt(sauve, 10);
            else if (actif) actif.scrollIntoView({ block: "center" });
            menu.addEventListener("scroll", function () { sessionStorage.setItem("menuScroll", menu.scrollTop); });
        }
    }

    /* ==================================================
       CONFIRMATIONS (validation de demandes, suppression d'employé)
       Délégation d'événements : fonctionne aussi pour les éléments ajoutés plus tard.
    ================================================== */

    document.addEventListener("click", function (event) {
        if (event.target.closest(".btn-validation")) {
            if (!confirm("Confirmez-vous cette action ?")) event.preventDefault();
        }
        const suppr = event.target.closest(".employee-action.btn-delete");
        if (suppr && !confirm("Voulez-vous supprimer cet utilisateur ?")) event.preventDefault();
    });

    /* ==================================================
       FORMULAIRES (conges/nouvelle.php, employes/ajouter.php, ...)
    ================================================== */

    $$("form").forEach(function (form) {
        if (form.classList.contains("login-form")) return; // déjà géré plus haut
        form.addEventListener("submit", function (event) {
            const vides = $$("[required]", form).filter(function (c) { return c.value.trim() === ""; });
            if (vides.length) {
                event.preventDefault();
                vides.forEach(marquerInvalide);
                showToast("Veuillez remplir tous les champs obligatoires.", "error");
            }
        });
    });
});
