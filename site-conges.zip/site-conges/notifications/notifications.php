<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login();
$u = user(); $repo = repo();
if ($_SERVER['REQUEST_METHOD'] === 'POST') { csrf_check(); $repo->readAll($u['utilisateurid']); flash('Notifications marquées comme lues.'); redirect('notifications.php'); }
$notifs = $repo->notifs($u['utilisateurid']);
layout_top('Notifications', 'notifications/notifications.php');
?>
<section class="dashboard-panel reveal">
    <h2>Mes notifications</h2>
    <div class="feed">
    <?php foreach ($notifs as $n) { $nonLue = ($n['lu'] === 'N'); ?>
        <div class="feed-item <?= $nonLue ? 'unread' : '' ?>">
            <div><strong><?= h($n['message']) ?></strong><small><?= h(date('d/m/Y H:i', strtotime($n['datenotification']))) ?></small></div>
            <span class="badge <?= $nonLue ? 'badge-new' : 'badge-seen' ?>"><?= $nonLue ? 'Non lue' : 'Lue' ?></span>
        </div>
    <?php } if (!$notifs) { ?><div class="empty-box">Aucune notification disponible</div><?php } ?>
    </div>
    <?php if ($notifs) { ?><form method="POST" style="margin-top:20px"><?= csrf_field() ?><button type="submit" class="btn-sm">Tout marquer comme lu</button></form><?php } ?>
</section>
<?php layout_bottom(); ?>
