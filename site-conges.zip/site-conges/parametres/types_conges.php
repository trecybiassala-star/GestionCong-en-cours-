<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['RH']);
$repo = repo();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $nom = trim($_POST['nom'] ?? ''); $jours = (int)($_POST['jours'] ?? -1);
    if ($nom === '' || strlen($nom) > 100 || $jours < 0 || $jours > 365) flash('Nom et nombre de jours (0 à 365) obligatoires.', 'error');
    else { $repo->addType($nom, $jours); flash("Type « $nom » ajouté."); }
    redirect('types_conges.php');
}
$types = $repo->types();
layout_top('Types de congés', 'parametres/types_conges.php');
?>
<section class="dashboard-panel reveal">
    <h2>Types de congés</h2>
    <div class="leave-type-container">
    <?php foreach ($types as $t) { ?><div class="leave-type-card"><h3><?= h($t['nomtype']) ?></h3><p><strong><?= (int)$t['joursannuels'] ?></strong> jours par an</p></div><?php } ?>
    </div>
</section>
<section class="dashboard-panel reveal">
    <h2>Ajouter un type</h2>
    <form method="POST"><?= csrf_field() ?>
        <div class="form-grid">
            <div class="input-group"><label for="nom">Nom du type</label><input id="nom" name="nom" maxlength="100" required></div>
            <div class="input-group"><label for="jours">Jours par an</label><input type="number" id="jours" name="jours" min="0" max="365" required></div>
        </div>
        <button type="submit">Ajouter</button>
    </form>
</section>
<?php layout_bottom(); ?>
