<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['RH']);
$users = repo()->users();
layout_top('Utilisateurs', 'parametres/utilisateurs.php');
?>
<section class="dashboard-panel reveal">
    <h2>Comptes utilisateurs (<?= count($users) ?>)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Nom</th><th>Identifiant (e-mail)</th><th>Rôle</th><th>Service</th></tr></thead>
        <tbody><?php foreach ($users as $x) { ?><tr><td><?= h($x['nom'] . ' ' . $x['prenom']) ?></td><td><?= h($x['email']) ?></td><td><?= h($x['nomrole']) ?></td><td><?= h($x['nomservice'] ?? '-') ?></td></tr><?php } ?></tbody>
    </table></div>
    <p style="margin-top:20px"><a class="btn-treat" href="../employes/liste.php">Ajouter un utilisateur</a></p>
</section>
<?php layout_bottom(); ?>
