<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['RH']);
$roles = repo()->roles();
$desc = ['Employé' => 'Crée et suit ses demandes de congé.', 'Responsable' => 'Valide les demandes de son équipe.', 'RH' => 'Gère les employés, les paramètres et les rapports.'];
layout_top('Rôles', 'parametres/roles.php');
?>
<section class="dashboard-panel reveal">
    <h2>Rôles de l'application</h2>
    <div class="role-container">
    <?php foreach ($roles as $r) { ?><div class="role-card"><h3><?= h($r['nomrole']) ?></h3><p><?= h($desc[$r['nomrole']] ?? '') ?></p><p><strong><?= (int)$r['nb'] ?></strong> utilisateur(s)</p></div><?php } ?>
    </div>
    <h2 style="margin-top:35px">Circuit de validation</h2>
    <div class="workflow-schema">
        <div class="workflow-role"><h3>Employé</h3><p>Soumet la demande</p></div><div class="workflow-arrow">→</div>
        <div class="workflow-role"><h3>Responsable</h3><p>Approuve ou refuse</p></div><div class="workflow-arrow">→</div>
        <div class="workflow-role"><h3>RH</h3><p>Suivi et rapports</p></div>
    </div>
</section>
<?php layout_bottom(); ?>
