<?php
require __DIR__ . '/includes/bootstrap.php';
require_login();
$u = user(); $role = $u['role']; $repo = repo();
$mes = $repo->statuts($u['utilisateurid']);
$notifs = $repo->notifs($u['utilisateurid'], 3);
$activites = $repo->histo($u['utilisateurid'], 3);
layout_top('Tableau de bord', 'dashboard.php');
?>

<?php if ($role === 'Employé') { ?>
<section class="dashboard-role employe-dashboard">
    <h2>Espace Employé</h2>
    <div class="statistics">
        <div class="stat-card"><h3>Mes demandes</h3><strong><?= array_sum($mes) ?></strong><p>Demandes effectuées</p></div>
        <div class="stat-card"><h3>Demandes approuvées</h3><strong><?= $mes['APPROUVEE'] ?></strong><p>Statut APPROUVEE</p></div>
        <div class="stat-card"><h3>Demandes en attente</h3><strong><?= $mes['EN_ATTENTE'] ?></strong><p>Statut EN ATTENTE</p></div>
    </div>
    <p><a class="btn-treat" href="conges/nouvelle.php">Faire une demande de congé</a></p>
</section>
<?php } ?>

<?php if ($role === 'Responsable' || $role === 'RH') {
    $aValider = $repo->aValider($u, 5); ?>
<section class="dashboard-role">
    <h2><?= $role === 'RH' ? 'Espace Ressources Humaines' : 'Espace Responsable' ?></h2>
    <div class="statistics">
    <?php if ($role === 'Responsable') { ?>
        <div class="stat-card"><h3>Demandes à valider</h3><strong><?= count($repo->aValider($u)) ?></strong><p>Demandes de l'équipe</p></div>
        <div class="stat-card"><h3>Employés suivis</h3><strong><?= $repo->employesSuivis($u['serviceid']) ?></strong><p>Membres de l'équipe</p></div>
    <?php } else { $all = $repo->statuts(); ?>
        <div class="stat-card"><h3>Nombre d'employés</h3><strong><?= count($repo->users()) ?></strong><p>Utilisateurs enregistrés</p></div>
        <div class="stat-card"><h3>Demandes en attente</h3><strong><?= $all['EN_ATTENTE'] ?></strong><p>Demandes à traiter</p></div>
        <div class="stat-card"><h3>Demandes validées</h3><strong><?= $all['APPROUVEE'] ?></strong><p>Congés approuvés</p></div>
        <div class="stat-card"><h3>Demandes refusées</h3><strong><?= $all['REFUSEE'] ?></strong><p>Congés refusés</p></div>
    <?php } ?>
    </div>

    <section class="dashboard-panel reveal">
        <h2>Demandes nécessitant une validation</h2>
        <div class="table-wrap"><table>
            <thead><tr><th>Employé</th><th>Type de congé</th><th>Date début</th><th>Date fin</th><th>Jours</th><th>Motif</th><th>Action</th></tr></thead>
            <tbody>
            <?php foreach ($aValider as $d) { ?>
                <tr><td><?= h($d['nom'] . ' ' . $d['prenom']) ?></td><td><?= h($d['nomtype']) ?></td><td><?= fdate($d['datedebut']) ?></td>
                    <td><?= fdate($d['datefin']) ?></td><td><?= (int)$d['nbjours'] ?></td><td><?= h($d['motif']) ?></td>
                    <td><a class="btn-treat" href="conges/validation.php?id=<?= (int)$d['demandeid'] ?>">Traiter</a></td></tr>
            <?php } if (!$aValider) { ?><tr><td colspan="7">Aucune demande disponible</td></tr><?php } ?>
            </tbody>
        </table></div>
    </section>
</section>
<?php } ?>

<section class="dashboard-panel reveal">
    <h2>Notifications récentes</h2>
    <div class="feed">
    <?php foreach ($notifs as $n) { $nonLue = ($n['lu'] === 'N'); ?>
        <div class="feed-item <?= $nonLue ? 'unread' : '' ?>">
            <div><strong><?= h($n['message']) ?></strong><small><?= h(date('d/m/Y H:i', strtotime($n['datenotification']))) ?></small></div>
            <span class="badge <?= $nonLue ? 'badge-new' : 'badge-seen' ?>"><?= $nonLue ? 'Non lue' : 'Lue' ?></span>
        </div>
    <?php } if (!$notifs) { ?><div class="empty-box">Aucune notification disponible</div><?php } ?>
    </div>
</section>

<section class="dashboard-panel reveal">
    <h2>Dernières activités</h2>
    <div class="feed">
    <?php foreach ($activites as $a) { ?>
        <div class="feed-item"><div><strong><?= h($a['action']) ?></strong><p>Demande n°<?= (int)$a['demandeid'] ?></p></div>
            <small><?= h(date('d/m/Y H:i', strtotime($a['dateaction']))) ?></small></div>
    <?php } if (!$activites) { ?><div class="empty-box">Aucune activité disponible</div><?php } ?>
    </div>
</section>

<?php layout_bottom(); ?>
