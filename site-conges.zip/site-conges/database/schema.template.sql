-- Schéma Gestion des congés (gabarit : {PK} et {ENGINE} sont remplacés selon SQLite ou MySQL)
CREATE TABLE IF NOT EXISTS role (roleid {PK}, nomrole VARCHAR(50) NOT NULL) {ENGINE};
CREATE TABLE IF NOT EXISTS service (serviceid {PK}, nomservice VARCHAR(100) NOT NULL) {ENGINE};
CREATE TABLE IF NOT EXISTS typeconge (typecongeid {PK}, nomtype VARCHAR(100) NOT NULL, joursannuels INT NOT NULL DEFAULT 0) {ENGINE};
CREATE TABLE IF NOT EXISTS utilisateurs (
  utilisateurid {PK}, nom VARCHAR(80) NOT NULL, prenom VARCHAR(80) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE,
  motpasse VARCHAR(255) NOT NULL, roleid INT NOT NULL, serviceid INT NULL,
  FOREIGN KEY (roleid) REFERENCES role(roleid), FOREIGN KEY (serviceid) REFERENCES service(serviceid)) {ENGINE};
CREATE TABLE IF NOT EXISTS demandeconge (
  demandeid {PK}, UtilisateurId INT NOT NULL, typecongeid INT NOT NULL, datedebut DATE NOT NULL, datefin DATE NOT NULL,
  nbjours INT NOT NULL, motif VARCHAR(255) NULL, statut VARCHAR(20) NOT NULL DEFAULT 'EN_ATTENTE', datedemande DATETIME NOT NULL,
  FOREIGN KEY (UtilisateurId) REFERENCES utilisateurs(utilisateurid), FOREIGN KEY (typecongeid) REFERENCES typeconge(typecongeid)) {ENGINE};
CREATE TABLE IF NOT EXISTS soldeconge (
  soldeid {PK}, utilisateurid INT NOT NULL, typecongeid INT NOT NULL, joursacquis INT NOT NULL DEFAULT 0, joursutilises INT NOT NULL DEFAULT 0,
  FOREIGN KEY (utilisateurid) REFERENCES utilisateurs(utilisateurid), FOREIGN KEY (typecongeid) REFERENCES typeconge(typecongeid)) {ENGINE};
CREATE TABLE IF NOT EXISTS validation (
  validationid {PK}, demandeid INT NOT NULL, validateurid INT NOT NULL, decision VARCHAR(20) NOT NULL, commentaire VARCHAR(255) NULL, datevalidation DATETIME NOT NULL,
  FOREIGN KEY (demandeid) REFERENCES demandeconge(demandeid), FOREIGN KEY (validateurid) REFERENCES utilisateurs(utilisateurid)) {ENGINE};
CREATE TABLE IF NOT EXISTS historique (
  historiqueid {PK}, utilisateurid INT NOT NULL, demandeid INT NULL, action VARCHAR(255) NOT NULL, dateaction DATETIME NOT NULL,
  FOREIGN KEY (utilisateurid) REFERENCES utilisateurs(utilisateurid)) {ENGINE};
CREATE TABLE IF NOT EXISTS notification (
  notificationid {PK}, utilisateurid INT NOT NULL, message VARCHAR(255) NOT NULL, lu CHAR(1) NOT NULL DEFAULT 'N', datenotification DATETIME NOT NULL,
  FOREIGN KEY (utilisateurid) REFERENCES utilisateurs(utilisateurid)) {ENGINE};

-- ===== Données de démonstration (mot de passe de tous les comptes : demo1234) =====
INSERT INTO role (roleid, nomrole) VALUES (1,'Employé'),(2,'Responsable'),(3,'RH');
INSERT INTO service (serviceid, nomservice) VALUES (1,'Informatique'),(2,'Commercial');
INSERT INTO typeconge (typecongeid, nomtype, joursannuels) VALUES (1,'Congé annuel',30),(2,'Congé maladie',15),(3,'Congé exceptionnel',5);
INSERT INTO utilisateurs (utilisateurid, nom, prenom, email, motpasse, roleid, serviceid) VALUES
 (1,'Sow','Aminata','aminata.sow@entreprise.com','$6$gX7u/jIeREFUwikA$TAQC8wo4lnDJSVkkxFdtiMHDZZ2c77Xw/5GBng.kDfPod7Bk9gVpL3oMkH4fMKQk.yW.PB6navCWUbywOz0dM.',1,1),
 (2,'Ba','Moussa','moussa.ba@entreprise.com','$6$gX7u/jIeREFUwikA$TAQC8wo4lnDJSVkkxFdtiMHDZZ2c77Xw/5GBng.kDfPod7Bk9gVpL3oMkH4fMKQk.yW.PB6navCWUbywOz0dM.',1,1),
 (3,'Diop','Ibrahima','ibrahima.diop@entreprise.com','$6$gX7u/jIeREFUwikA$TAQC8wo4lnDJSVkkxFdtiMHDZZ2c77Xw/5GBng.kDfPod7Bk9gVpL3oMkH4fMKQk.yW.PB6navCWUbywOz0dM.',2,1),
 (4,'Fall','Khady','khady.fall@entreprise.com','$6$gX7u/jIeREFUwikA$TAQC8wo4lnDJSVkkxFdtiMHDZZ2c77Xw/5GBng.kDfPod7Bk9gVpL3oMkH4fMKQk.yW.PB6navCWUbywOz0dM.',3,2),
 (5,'Ndiaye','Cheikh','cheikh.ndiaye@entreprise.com','$6$gX7u/jIeREFUwikA$TAQC8wo4lnDJSVkkxFdtiMHDZZ2c77Xw/5GBng.kDfPod7Bk9gVpL3oMkH4fMKQk.yW.PB6navCWUbywOz0dM.',1,2);
INSERT INTO soldeconge (utilisateurid, typecongeid, joursacquis, joursutilises)
 SELECT u.utilisateurid, t.typecongeid, t.joursannuels, 0 FROM utilisateurs u, typeconge t;
INSERT INTO demandeconge (demandeid, UtilisateurId, typecongeid, datedebut, datefin, nbjours, motif, statut, datedemande) VALUES
 (1,1,1,'2026-11-16','2026-11-20',5,'Repos familial','EN_ATTENTE','2026-11-02 09:10:00'),
 (2,2,1,'2026-12-21','2026-12-31',8,'Fêtes de fin d''année','EN_ATTENTE','2026-11-03 14:25:00'),
 (3,1,2,'2026-09-07','2026-09-09',3,'Grippe','APPROUVEE','2026-09-07 08:00:00'),
 (4,5,3,'2026-10-12','2026-10-12',1,'Démarche administrative','REFUSEE','2026-10-05 10:00:00'),
 (5,2,1,'2026-08-03','2026-08-14',10,'Vacances','APPROUVEE','2026-07-10 16:40:00');
UPDATE soldeconge SET joursutilises = 3 WHERE utilisateurid = 1 AND typecongeid = 2;
UPDATE soldeconge SET joursutilises = 10 WHERE utilisateurid = 2 AND typecongeid = 1;
INSERT INTO validation (demandeid, validateurid, decision, commentaire, datevalidation) VALUES
 (3,3,'APPROUVEE','Bon rétablissement','2026-09-07 11:00:00'),(4,4,'REFUSEE','Pièce justificative manquante','2026-10-06 09:30:00'),
 (5,3,'APPROUVEE','Bonnes vacances','2026-07-11 10:00:00');
INSERT INTO historique (utilisateurid, demandeid, action, dateaction) VALUES
 (1,3,'Demande créée','2026-09-07 08:00:00'),(3,3,'Demande approuvée','2026-09-07 11:00:00'),
 (1,1,'Demande créée','2026-11-02 09:10:00'),(2,2,'Demande créée','2026-11-03 14:25:00'),(4,4,'Demande refusée','2026-10-06 09:30:00');
INSERT INTO notification (utilisateurid, message, lu, datenotification) VALUES
 (3,'Nouvelle demande de congé à valider (n°1).','N','2026-11-02 09:10:00'),
 (3,'Nouvelle demande de congé à valider (n°2).','N','2026-11-03 14:25:00'),
 (1,'Votre demande n°3 a été approuvée.','O','2026-09-07 11:00:00'),
 (5,'Votre demande n°4 a été refusée.','N','2026-10-06 09:30:00');
