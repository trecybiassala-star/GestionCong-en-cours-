<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['RH']);
$lignes = repo()->histo(null, 100);
layout_top('Historique des actions', 'historique/historique.php');
?>
<section class="dashboard-panel reveal">
    <h2>100 dernières actions</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Demande</th></tr></thead>
        <tbody>
        <?php foreach ($lignes as $l) { ?><tr><td><?= h(date('d/m/Y H:i', strtotime($l['dateaction']))) ?></td><td><?= h($l['nom'] . ' ' . $l['prenom']) ?></td><td><?= h($l['action']) ?></td><td><?= $l['demandeid'] ? 'n°' . (int)$l['demandeid'] : '-' ?></td></tr><?php }
        if (!$lignes) { ?><tr><td colspan="4">Aucune action enregistrée.</td></tr><?php } ?>
        </tbody>
    </table></div>
</section>
<?php layout_bottom(); ?>
