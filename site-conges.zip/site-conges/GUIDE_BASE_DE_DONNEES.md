# Guide : fiabiliser la connexion à la base (XAMPP / phpMyAdmin)

## 1. Démarrer et tester
1. Panneau XAMPP : démarrez **Apache** et **MySQL** (ils doivent être verts). Notez le port MySQL (3306, parfois 3307 si un autre MySQL tourne). Reportez-le dans `$DB_PORT` de `Configuration/Connection.php`.
2. Ouvrez `http://localhost/phpmyadmin`. Si la page s'ouvre, MySQL fonctionne.

## 2. Créer la base avec le bon encodage
Onglet **Bases de données** → nom `WORKFLOW` → interclassement **utf8mb4_general_ci** → Créer.
Pour une base existante : onglet **Opérations** → Interclassement → utf8mb4_general_ci → cocher « Changer l'interclassement de toutes les tables » → Exécuter.

Sans cet encodage, la comparaison `nomrole = 'Employé'` peut échouer et le tableau de bord n'affiche aucun bloc.

## 3. Vérifier les noms (cause n°1 des pages « qui ne se connectent pas »)
Le code utilise ces noms. Comparez-les à l'onglet **Structure** de chaque table :

| Table | Colonnes utilisées |
|---|---|
| `utilisateurs` | utilisateurid, nom, prenom, email, motpasse, roleid, serviceid |
| `role` | roleid, nomrole |
| `demandeconge` | demandeid, UtilisateurId, statut, + dates, jours, motif, type |
| `typeconge` | clé du type, libellé |
| `notification` | notificationid, utilisateurid, message, lu, datenotification |
| `historique` | historiqueid, demandeid, utilisateurid, action, dateaction |

- Les **noms de tables** sont sensibles à la casse sous Linux (pas sous Windows) : écrivez-les toujours en minuscules, comme ci-dessus.
- Dans `TraitementDashboard.php`, le tableau `$COL` regroupe les colonnes de `demandeconge` et `typeconge` dont je n'ai pas vu le schéma (`datedebut`, `datefin`, `nbjours`, `motif`, `typecongeid`, `nomtype`). **Corrigez-les selon votre structure.**

Vérifiez aussi les valeurs réelles, qui doivent être identiques à celles du code :
```sql
SELECT DISTINCT statut FROM demandeconge;   -- EN_ATTENTE, APPROUVEE, REFUSEE
SELECT roleid, nomrole FROM role;           -- Employé, Responsable, RH
SELECT DISTINCT lu FROM notification;       -- N / O  (ou 0 / 1)
```

## 4. Activer le détail des erreurs
Dans `TraitementDashboard.php`, mettez `const DEBUG_BD = true;` : un bandeau jaune affiche l'erreur SQL exacte (colonne inconnue, table absente…). Remettez `false` avant toute mise en ligne.

## 5. Erreurs fréquentes
| Message | Cause | Solution |
|---|---|---|
| `Access denied for user` | Mauvais utilisateur ou mot de passe | Corrigez `$DB_USER` / `$DB_PASS` |
| `Unknown database 'workflow'` | Nom de base différent | Même casse que dans phpMyAdmin |
| `No such file or directory (2002)` / `Connection refused` | MySQL arrêté ou mauvais port | Démarrez MySQL, ajustez `$DB_PORT` |
| `Table '...' doesn't exist` | Casse du nom de table | Renommez la table en minuscules |
| `Unknown column` | Colonne mal nommée | Corrigez `$COL` ou la requête |
| `Call to undefined function mysqli_...` | Extension manquante | Activez `extension=mysqli` dans php.ini |
| Page blanche | Erreur PHP masquée | Consultez `xampp/apache/logs/error.log` |

## 6. Créer un utilisateur MySQL dédié (au lieu de `root` sans mot de passe)
Dans phpMyAdmin → onglet **SQL** :
```sql
CREATE USER 'conges_app'@'localhost' IDENTIFIED BY 'UnMotDePasseSolide!';
GRANT SELECT, INSERT, UPDATE, DELETE ON WORKFLOW.* TO 'conges_app'@'localhost';
FLUSH PRIVILEGES;
```
Puis mettez `$DB_USER = "conges_app"` et le mot de passe dans `Connection.php`.

## 7. Index : des requêtes plus rapides
```sql
CREATE INDEX idx_demande_user_statut ON demandeconge (UtilisateurId, statut);
CREATE INDEX idx_notif_user_date     ON notification (utilisateurid, datenotification);
CREATE INDEX idx_histo_user_date     ON historique (utilisateurid, dateaction);
CREATE INDEX idx_user_service        ON utilisateurs (serviceid, roleid);
```

## 8. Intégrité : clés étrangères
Onglet **Concepteur** de la base pour visualiser les liens. Exemple (adaptez les noms) :
```sql
ALTER TABLE demandeconge
  ADD CONSTRAINT fk_demande_user FOREIGN KEY (UtilisateurId) REFERENCES utilisateurs(utilisateurid);
```
Les tables doivent être en moteur **InnoDB** (onglet Opérations → Moteur de stockage).

## 9. Mots de passe : ne plus les stocker en clair
```sql
ALTER TABLE utilisateurs MODIFY motpasse VARCHAR(255) NOT NULL;
```
Migration unique (à exécuter une fois, puis supprimer le script) :
```php
$r = mysqli_query($conn, "SELECT utilisateurid, motpasse FROM utilisateurs");
while ($u = mysqli_fetch_assoc($r)) {
    $hash = password_hash($u['motpasse'], PASSWORD_DEFAULT);
    $s = mysqli_prepare($conn, "UPDATE utilisateurs SET motpasse = ? WHERE utilisateurid = ?");
    mysqli_stmt_bind_param($s, "si", $hash, $u['utilisateurid']);
    mysqli_stmt_execute($s);
}
```
Dans `Traitement/Authentification/ConnectionIndex.php`, remplacez la comparaison directe par `password_verify($_POST['password'], $ligne['motpasse'])`, appelez `session_regenerate_id(true)` après succès et redirigez les échecs vers `index.php?erreur=1` (le script JS affichera un message animé).

## 9 bis. Requêtes préparées partout
Toute valeur venant de l'utilisateur passe par `mysqli_prepare` + `bind_param` (comme dans `TraitementDashboard.php`), jamais concaténée dans le SQL.

## 10. Sauvegarde et partage du schéma
phpMyAdmin → base `WORKFLOW` → **Exporter** → méthode Personnalisée → cocher « Structure » (et « Données » pour un jeu de test) → fichier `.sql`. Ajoutez-le au projet : le README signale que le schéma manque.
