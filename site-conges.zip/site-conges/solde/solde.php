<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login();
$soldes = repo()->soldes(user()['utilisateurid']);
layout_top('Solde de congés', 'solde/solde.php');
?>
<section class="dashboard-panel reveal">
    <h2>Mon solde par type de congé</h2>
    <?php foreach ($soldes as $s) { $acq = max(1, (int)$s['joursacquis']); $pct = min(100, round($s['joursutilises'] / $acq * 100)); ?>
        <div class="solde-ligne">
            <div class="solde-titre"><strong><?= h($s['nomtype']) ?></strong><span><?= (int)$s['restant'] ?> jour(s) restant(s) sur <?= (int)$s['joursacquis'] ?></span></div>
            <div class="bar"><span style="width:<?= $pct ?>%"></span></div>
            <small><?= (int)$s['joursutilises'] ?> jour(s) utilisé(s)</small>
        </div>
    <?php } if (!$soldes) { ?><div class="empty-box">Aucun solde enregistré.</div><?php } ?>
</section>
<?php layout_bottom(); ?>
