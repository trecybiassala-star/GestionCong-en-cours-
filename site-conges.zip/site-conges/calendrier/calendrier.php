<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login();
$u = user(); $repo = repo();
$m = $_GET['m'] ?? date('Y-m');
if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $m)) $m = date('Y-m');
$premier = strtotime("$m-01"); $nbj = (int)date('t', $premier);
$debut = "$m-01"; $fin = "$m-" . sprintf('%02d', $nbj);
$prec = date('Y-m', strtotime('-1 month', $premier)); $suiv = date('Y-m', strtotime('+1 month', $premier));

$where = "d.statut <> 'REFUSEE' AND d.datedebut <= ? AND d.datefin >= ?"; $p = [$fin, $debut];
if ($u['role'] !== 'RH') { $where .= " AND u.serviceid = ?"; $p[] = $u['serviceid']; }   // l'équipe du service
$evts = $repo->demandes($where, $p);
$mois = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
layout_top('Calendrier', 'calendrier/calendrier.php');
?>
<section class="dashboard-panel reveal">
    <div class="calendar-container">
        <div class="calendar-header">
            <a class="calendar-btn" href="?m=<?= $prec ?>">‹</a>
            <h3><?= $mois[(int)date('n', $premier) - 1] . ' ' . date('Y', $premier) ?></h3>
            <a class="calendar-btn" href="?m=<?= $suiv ?>">›</a>
        </div>
        <div class="calendar-grid">
            <?php foreach (['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'] as $j) { ?><div class="calendar-day-name"><?= $j ?></div><?php } ?>
            <?php for ($i = 1; $i < (int)date('N', $premier); $i++) { ?><div class="calendar-day empty"></div><?php } ?>
            <?php for ($j = 1; $j <= $nbj; $j++) { $dj = sprintf('%s-%02d', $m, $j); ?>
                <div class="calendar-day <?= $dj === date('Y-m-d') ? 'aujourdhui' : '' ?>"><div class="day-number"><?= $j ?></div>
                <?php foreach ($evts as $e) if ($e['datedebut'] <= $dj && $e['datefin'] >= $dj) { ?>
                    <div class="event <?= $e['statut'] === 'APPROUVEE' ? 'approved' : 'pending' ?>" title="<?= h($e['nomtype']) ?>"><?= h($e['prenom'] . ' ' . substr($e['nom'], 0, 1) . '.') ?></div>
                <?php } ?></div>
            <?php } ?>
        </div>
        <div class="calendar-legend">
            <span><span class="legend approved"></span>Approuvé</span><span><span class="legend pending"></span>En attente</span>
        </div>
    </div>
</section>
<?php layout_bottom(); ?>
