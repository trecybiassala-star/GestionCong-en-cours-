<?php
function layout_top(string $title, string $active = ''): void {
    global $base;
    $u = user(); $role = $u['role'];
    $nb = repo()->n("SELECT COUNT(*) FROM notification WHERE utilisateurid = ? AND lu = 'N'", [$u['utilisateurid']]);
    $menu = [
        ['Espace personnel', [['employes/profil.php', 'Mon profil'], ['conges/nouvelle.php', 'Nouvelle demande'],
                              ['conges/liste.php', 'Mes demandes'], ['solde/solde.php', 'Solde de congés']]],
        ['Workflow', [['conges/validation.php', 'Validation des demandes', ['Responsable', 'RH']],
                      ['calendrier/calendrier.php', 'Calendrier']]],
        ['Gestion RH', [['employes/liste.php', 'Gestion des employés', ['RH']], ['rapports/rapport.php', 'Rapports', ['RH']],
                        ['historique/historique.php', 'Historique des actions', ['RH']]]],
        ['Configuration RH', [['parametres/utilisateurs.php', 'Utilisateurs', ['RH']], ['parametres/roles.php', 'Rôles', ['RH']],
                              ['parametres/types_conges.php', 'Types de congés', ['RH']]]],
        ['Communication', [['notifications/notifications.php', 'Notifications']]],
    ];
    $f = flash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($title) ?> - Gestion des Congés</title>
<script>document.documentElement.className += " js";</script>
<link rel="stylesheet" href="<?= $base ?>CSS.css">
<link rel="stylesheet" href="<?= $base ?>animations.css">
<link rel="stylesheet" href="<?= $base ?>site.css">
</head>
<body>
<button class="menu-toggle" type="button" aria-label="Ouvrir le menu">☰</button>
<div class="sidebar-backdrop"></div>
<div class="dashboard-container">
<aside class="sidebar">
    <div class="sidebar-logo"><h2>Gestion Congés</h2></div>
    <nav>
        <a href="<?= $base ?>dashboard.php" class="<?= $active === 'dashboard.php' ? 'active' : '' ?>">Tableau de bord</a>
        <?php foreach ($menu as [$titre, $liens]) {
            $visibles = array_filter($liens, fn($l) => !isset($l[2]) || in_array($role, $l[2], true));
            if (!$visibles) continue; ?>
            <div class="menu-title"><?= h($titre) ?></div>
            <?php foreach ($visibles as $l) { ?>
                <a href="<?= $base . $l[0] ?>" class="<?= $active === $l[0] ? 'active' : '' ?>"><?= h($l[1]) ?>
                <?php if ($l[0] === 'notifications/notifications.php' && $nb > 0) { ?><span class="nb-pill"><?= $nb ?></span><?php } ?></a>
            <?php }
        } ?>
        <a href="<?= $base ?>Deconnexion.php" class="logout">Déconnexion</a>
    </nav>
</aside>
<main class="main-content">
<header class="top-header">
    <div><h1><?= h($title) ?></h1><p id="live-clock">Gestion professionnelle des congés</p></div>
    <div class="profile-box"><?= h($u['nom'] . ' ' . $u['prenom']) ?><br><?= h($role) ?></div>
</header>
<?php if ($f) { ?><div id="flash" data-type="<?= h($f[1]) ?>" data-msg="<?= h($f[0]) ?>" hidden></div><?php } ?>
<?php }

function layout_bottom(): void {
    global $base; ?>
</main>
</div>
<script src="<?= $base ?>Scripts.js"></script>
</body>
</html>
<?php }
