<?php
define('ROOT', dirname(__DIR__));
session_start();
$cfg = require ROOT . '/Configuration/config.php';
require_once __DIR__ . '/Repo.php';
require_once __DIR__ . '/layout.php';

// Préfixe vers la racine : '' à la racine, '../' dans un sous-dossier
$base = (realpath(dirname($_SERVER['SCRIPT_FILENAME'])) === realpath(ROOT)) ? '' : '../';

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function repo(): Repo { static $r = null; global $cfg; return $r ??= new Repo($cfg); }
function redirect(string $url) { header("Location: $url"); exit; }
function fdate($d) { return $d ? date('d/m/Y', strtotime($d)) : '-'; }

function flash(?string $msg = null, string $type = 'success') {
    if ($msg !== null) { $_SESSION['flash'] = [$msg, $type]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf() . '">'; }
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(400); die('Requête invalide (jeton CSRF).'); }
}

function user(): ?array {
    if (!isset($_SESSION['utilisateurid'], $_SESSION['role'])) return null;
    return ['utilisateurid' => (int)$_SESSION['utilisateurid'], 'nom' => $_SESSION['nom'] ?? '',
            'prenom' => $_SESSION['prenom'] ?? '', 'role' => $_SESSION['role'], 'serviceid' => (int)($_SESSION['serviceid'] ?? 0)];
}
function require_login(array $roles = []): void {
    global $base;
    $u = user();
    if (!$u) redirect($base . 'index.php?erreur=Veuillez vous connecter.');
    if ($roles && !in_array($u['role'], $roles, true)) {
        flash('Accès refusé pour votre rôle.', 'error'); redirect($base . 'dashboard.php');
    }
}

/** Nombre de jours ouvrés (lundi-vendredi) entre deux dates incluses. */
function jours_ouvres(string $debut, string $fin): int {
    $n = 0;
    for ($t = strtotime($debut); $t <= strtotime($fin); $t += 86400) { if ((int)date('N', $t) < 6) $n++; }
    return $n;
}
function badge_statut(string $s): string {
    $l = ['EN_ATTENTE' => 'En attente', 'APPROUVEE' => 'Approuvée', 'REFUSEE' => 'Refusée'][$s] ?? $s;
    return '<span class="statut ' . h($s) . '">' . h($l) . '</span>';
}
