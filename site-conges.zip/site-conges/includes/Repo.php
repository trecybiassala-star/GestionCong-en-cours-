<?php
/**
 * Accès aux données : TOUTES les requêtes SQL de l'application sont ici.
 * Si votre base réelle utilise d'autres noms de tables/colonnes, adaptez uniquement ce fichier.
 */
class Repo {
    public ?PDO $db = null;
    private bool $sqlite;

    public function __construct(array $c) {
        $this->sqlite = ($c['mode'] !== 'mysql');
        try {
            if ($this->sqlite) {
                $f = $c['sqlite'];
                if (!is_dir(dirname($f))) mkdir(dirname($f), 0775, true);
                $nouveau = !file_exists($f) || filesize($f) === 0;
                $this->db = new PDO('sqlite:' . $f);
                $this->options();
                if ($nouveau) {
                    try { $this->db->exec($this->schema()); }
                    catch (Throwable $e) { $this->db = null; @unlink($f); throw $e; }
                }
            } else {
                $m = $c['mysql'];
                $this->db = new PDO("mysql:host={$m['host']};port={$m['port']};dbname={$m['name']};charset=utf8mb4", $m['user'], $m['pass']);
                $this->options();
            }
        } catch (Throwable $e) {
            error_log('[BD] ' . $e->getMessage());
            http_response_code(500);
            die('Connexion à la base de données impossible. Vérifiez Configuration/config.php et que MySQL est démarré.'
                . (!empty($c['debug']) ? '<br><small>' . htmlspecialchars($e->getMessage()) . '</small>' : ''));
        }
    }

    private function options(): void {
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }
    private function schema(): string {
        return str_replace(['{PK}', '{ENGINE}'], ['INTEGER PRIMARY KEY AUTOINCREMENT', ''],
                           file_get_contents(ROOT . '/database/schema.template.sql'));
    }

    // ---------- outils ----------
    public function q(string $sql, array $p = []): PDOStatement { $s = $this->db->prepare($sql); $s->execute($p); return $s; }
    public function all(string $sql, array $p = []): array { return $this->q($sql, $p)->fetchAll(); }
    public function one(string $sql, array $p = []): ?array { $r = $this->q($sql, $p)->fetch(); return $r ?: null; }
    public function n(string $sql, array $p = []): int { return (int)$this->q($sql, $p)->fetchColumn(); }
    private function now(): string { return date('Y-m-d H:i:s'); }

    // ---------- authentification ----------
    public function login(string $email, string $pwd): ?array {
        $u = $this->one("SELECT u.utilisateurid, u.nom, u.prenom, u.email, u.motpasse, u.serviceid, r.nomrole AS role
                         FROM utilisateurs u INNER JOIN role r ON u.roleid = r.roleid WHERE u.email = ?", [$email]);
        if (!$u || $pwd === '' || $u['motpasse'] === '') return null;
        $s = $u['motpasse'];
        $hache = ($s[0] === '$');
        $ok = $hache ? password_verify($pwd, $s) : hash_equals($s, $pwd);   // accepte les anciens mots de passe en clair
        if (!$ok) return null;
        if (!$hache) $this->setPassword((int)$u['utilisateurid'], $pwd);      // migration automatique vers un hash
        unset($u['motpasse']);
        return $u;
    }
    public function setPassword(int $id, string $pwd): void {
        $this->q("UPDATE utilisateurs SET motpasse = ? WHERE utilisateurid = ?", [password_hash($pwd, PASSWORD_DEFAULT), $id]);
    }

    // ---------- référentiels ----------
    public function user(int $id): ?array {
        return $this->one("SELECT u.*, r.nomrole, s.nomservice FROM utilisateurs u INNER JOIN role r ON u.roleid = r.roleid
                           LEFT JOIN service s ON u.serviceid = s.serviceid WHERE u.utilisateurid = ?", [$id]);
    }
    public function users(): array {
        return $this->all("SELECT u.utilisateurid, u.nom, u.prenom, u.email, r.nomrole, s.nomservice FROM utilisateurs u
                           INNER JOIN role r ON u.roleid = r.roleid LEFT JOIN service s ON u.serviceid = s.serviceid ORDER BY u.nom, u.prenom");
    }
    public function roles(): array {
        return $this->all("SELECT r.roleid, r.nomrole, (SELECT COUNT(*) FROM utilisateurs u WHERE u.roleid = r.roleid) AS nb FROM role r ORDER BY r.roleid");
    }
    public function services(): array { return $this->all("SELECT serviceid, nomservice FROM service ORDER BY nomservice"); }
    public function types(): array { return $this->all("SELECT typecongeid, nomtype, joursannuels FROM typeconge ORDER BY typecongeid"); }

    public function addType(string $nom, int $jours): void {
        $this->q("INSERT INTO typeconge (nomtype, joursannuels) VALUES (?, ?)", [$nom, $jours]);
        $id = (int)$this->db->lastInsertId();
        foreach ($this->all("SELECT utilisateurid FROM utilisateurs") as $u)
            $this->q("INSERT INTO soldeconge (utilisateurid, typecongeid, joursacquis, joursutilises) VALUES (?, ?, ?, 0)", [$u['utilisateurid'], $id, $jours]);
    }
    public function addUser(string $nom, string $prenom, string $email, string $pwd, int $roleId, ?int $serviceId): void {
        $this->q("INSERT INTO utilisateurs (nom, prenom, email, motpasse, roleid, serviceid) VALUES (?, ?, ?, ?, ?, ?)",
                 [$nom, $prenom, $email, password_hash($pwd, PASSWORD_DEFAULT), $roleId, $serviceId]);
        $id = (int)$this->db->lastInsertId();
        foreach ($this->types() as $t)
            $this->q("INSERT INTO soldeconge (utilisateurid, typecongeid, joursacquis, joursutilises) VALUES (?, ?, ?, 0)", [$id, $t['typecongeid'], $t['joursannuels']]);
    }
    public function emailExiste(string $email): bool { return $this->n("SELECT COUNT(*) FROM utilisateurs WHERE email = ?", [$email]) > 0; }

    // ---------- demandes ----------
    /** $where : fragment SQL FIXE écrit dans le code (jamais issu d'une saisie), valeurs dans $p. */
    public function demandes(string $where = '1=1', array $p = [], int $limit = 0): array {
        return $this->all("SELECT d.demandeid, d.UtilisateurId AS uid, u.nom, u.prenom, u.serviceid, t.nomtype, d.typecongeid,
                                  d.datedebut, d.datefin, d.nbjours, d.motif, d.statut, d.datedemande
                           FROM demandeconge d INNER JOIN utilisateurs u ON d.UtilisateurId = u.utilisateurid
                           INNER JOIN typeconge t ON d.typecongeid = t.typecongeid
                           WHERE $where ORDER BY d.datedemande DESC, d.demandeid DESC" . ($limit ? " LIMIT " . (int)$limit : ""), $p);
    }
    public function aValider(array $u, int $limit = 0): array {
        if ($u['role'] === 'RH')
            return $this->demandes("d.statut = 'EN_ATTENTE' AND d.UtilisateurId <> ?", [$u['utilisateurid']], $limit);
        return $this->demandes("d.statut = 'EN_ATTENTE' AND u.serviceid = ? AND d.UtilisateurId <> ?
                                AND u.roleid = (SELECT roleid FROM role WHERE nomrole = 'Employé')", [$u['serviceid'], $u['utilisateurid']], $limit);
    }
    public function statuts(?int $uid = null): array {
        $r = $uid === null ? $this->all("SELECT statut, COUNT(*) AS nb FROM demandeconge GROUP BY statut")
                           : $this->all("SELECT statut, COUNT(*) AS nb FROM demandeconge WHERE UtilisateurId = ? GROUP BY statut", [$uid]);
        $o = ['EN_ATTENTE' => 0, 'APPROUVEE' => 0, 'REFUSEE' => 0];
        foreach ($r as $l) $o[$l['statut']] = (int)$l['nb'];
        return $o;
    }
    public function chevauche(int $uid, string $debut, string $fin): bool {
        return $this->n("SELECT COUNT(*) FROM demandeconge WHERE UtilisateurId = ? AND statut <> 'REFUSEE' AND datedebut <= ? AND datefin >= ?", [$uid, $fin, $debut]) > 0;
    }
    public function restant(int $uid, int $typeId): ?int {
        $r = $this->one("SELECT joursacquis - joursutilises AS restant FROM soldeconge WHERE utilisateurid = ? AND typecongeid = ?", [$uid, $typeId]);
        return $r ? (int)$r['restant'] : null;
    }
    public function addDemande(int $uid, int $typeId, string $debut, string $fin, int $jours, string $motif): int {
        $this->q("INSERT INTO demandeconge (UtilisateurId, typecongeid, datedebut, datefin, nbjours, motif, statut, datedemande)
                  VALUES (?, ?, ?, ?, ?, ?, 'EN_ATTENTE', ?)", [$uid, $typeId, $debut, $fin, $jours, $motif, $this->now()]);
        $id = (int)$this->db->lastInsertId();
        $this->log($uid, $id, 'Demande créée');
        $svc = $this->one("SELECT serviceid FROM utilisateurs WHERE utilisateurid = ?", [$uid])['serviceid'] ?? null;
        $dest = $this->all("SELECT u.utilisateurid FROM utilisateurs u INNER JOIN role r ON u.roleid = r.roleid
                            WHERE r.nomrole = 'Responsable' AND u.serviceid = ?", [$svc]);
        if (!$dest) $dest = $this->all("SELECT u.utilisateurid FROM utilisateurs u INNER JOIN role r ON u.roleid = r.roleid WHERE r.nomrole = 'RH'");
        foreach ($dest as $d) $this->notify((int)$d['utilisateurid'], "Nouvelle demande de congé à valider (n°$id).");
        return $id;
    }
    public function decide(int $id, int $validateur, string $decision, string $commentaire): bool {
        $d = $this->one("SELECT UtilisateurId AS uid, typecongeid, nbjours FROM demandeconge WHERE demandeid = ?", [$id]);
        if (!$d) return false;
        $this->db->beginTransaction();
        try {
            $st = $this->q("UPDATE demandeconge SET statut = ? WHERE demandeid = ? AND statut = 'EN_ATTENTE'", [$decision, $id]);
            if ($st->rowCount() !== 1) throw new RuntimeException('Demande déjà traitée');
            $this->q("INSERT INTO validation (demandeid, validateurid, decision, commentaire, datevalidation) VALUES (?, ?, ?, ?, ?)",
                     [$id, $validateur, $decision, $commentaire, $this->now()]);
            if ($decision === 'APPROUVEE')
                $this->q("UPDATE soldeconge SET joursutilises = joursutilises + ? WHERE utilisateurid = ? AND typecongeid = ?", [$d['nbjours'], $d['uid'], $d['typecongeid']]);
            $verbe = $decision === 'APPROUVEE' ? 'approuvée' : 'refusée';
            $this->log($validateur, $id, "Demande $verbe");
            $this->notify((int)$d['uid'], "Votre demande n°$id a été $verbe.");
            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            $this->db->rollBack(); error_log('[decide] ' . $e->getMessage()); return false;
        }
    }

    // ---------- soldes, notifications, historique ----------
    public function soldes(int $uid): array {
        return $this->all("SELECT t.nomtype, s.joursacquis, s.joursutilises, (s.joursacquis - s.joursutilises) AS restant
                           FROM soldeconge s INNER JOIN typeconge t ON s.typecongeid = t.typecongeid WHERE s.utilisateurid = ? ORDER BY t.typecongeid", [$uid]);
    }
    public function notifs(int $uid, int $limit = 50): array {
        return $this->all("SELECT notificationid, message, lu, datenotification FROM notification WHERE utilisateurid = ?
                           ORDER BY datenotification DESC, notificationid DESC LIMIT " . (int)$limit, [$uid]);
    }
    public function readAll(int $uid): void { $this->q("UPDATE notification SET lu = 'O' WHERE utilisateurid = ?", [$uid]); }
    public function notify(int $uid, string $msg): void {
        $this->q("INSERT INTO notification (utilisateurid, message, lu, datenotification) VALUES (?, ?, 'N', ?)", [$uid, $msg, $this->now()]);
    }
    public function log(int $uid, ?int $demandeId, string $action): void {
        $this->q("INSERT INTO historique (utilisateurid, demandeid, action, dateaction) VALUES (?, ?, ?, ?)", [$uid, $demandeId, $action, $this->now()]);
    }
    public function histo(?int $uid = null, int $limit = 100): array {
        $w = $uid === null ? '1=1' : 'h.utilisateurid = ?';
        return $this->all("SELECT h.historiqueid, h.demandeid, h.action, h.dateaction, u.nom, u.prenom FROM historique h
                           INNER JOIN utilisateurs u ON h.utilisateurid = u.utilisateurid WHERE $w
                           ORDER BY h.dateaction DESC, h.historiqueid DESC LIMIT " . (int)$limit, $uid === null ? [] : [$uid]);
    }
    public function rapportTypes(): array {
        return $this->all("SELECT t.nomtype, COUNT(*) AS nb, SUM(d.nbjours) AS jours FROM demandeconge d
                           INNER JOIN typeconge t ON d.typecongeid = t.typecongeid WHERE d.statut = 'APPROUVEE' GROUP BY t.nomtype ORDER BY jours DESC");
    }
    public function rapportServices(): array {
        return $this->all("SELECT s.nomservice, COUNT(*) AS nb FROM demandeconge d INNER JOIN utilisateurs u ON d.UtilisateurId = u.utilisateurid
                           INNER JOIN service s ON u.serviceid = s.serviceid GROUP BY s.nomservice ORDER BY nb DESC");
    }
    public function employesSuivis(int $serviceId): int {
        return $this->n("SELECT COUNT(*) FROM utilisateurs u INNER JOIN role r ON u.roleid = r.roleid WHERE u.serviceid = ? AND r.nomrole = 'Employé'", [$serviceId]);
    }
}
