<?php
require __DIR__ . '/includes/bootstrap.php';
if (user()) redirect('dashboard.php');

$erreur = $_GET['erreur'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (($_SESSION['echecs'] ?? 0) >= 5 && time() < ($_SESSION['blocage'] ?? 0)) {
        $erreur = 'Trop de tentatives. Réessayez dans quelques secondes.';
    } else {
        $u = repo()->login(trim($_POST['email'] ?? ''), $_POST['password'] ?? '');
        if ($u) {
            session_regenerate_id(true);
            $_SESSION['echecs'] = 0;
            foreach (['utilisateurid', 'nom', 'prenom', 'role', 'serviceid'] as $k) $_SESSION[$k] = $u[$k];
            redirect('dashboard.php');
        }
        $_SESSION['echecs'] = ($_SESSION['echecs'] ?? 0) + 1;
        if ($_SESSION['echecs'] >= 5) $_SESSION['blocage'] = time() + 30;
        $erreur = 'Identifiants incorrects.';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestion des Congés</title>
<link rel="stylesheet" href="CSS.css">
<link rel="stylesheet" href="animations.css">
<link rel="stylesheet" href="site.css">
</head>
<body>
<div class="page-container">

    <section class="left-section">
        <div class="brand">
            <img src="images/logo.svg" alt="Logo Gestion Congés" class="logo">
            <h1>Gestion des Congés</h1>
        </div>
        <div class="presentation">
            <h2>Simplifiez la gestion des absences</h2>
            <p>Une plateforme professionnelle permettant de gérer les demandes, validations et suivis de congés.</p>
            <img src="images/illustration-rh.svg" alt="Illustration gestion RH" class="illustration">
            <div class="advantages">
                <p>Gestion des demandes de congés</p>
                <p>Validation par les responsables</p>
                <p>Suivi du solde et historique</p>
            </div>
        </div>
    </section>

    <section class="right-section">
        <div class="login-card">
            <div class="login-header">
                <img src="images/logo.svg" alt="Logo" class="login-logo">
                <h2>Bienvenue</h2>
                <p>Connectez-vous à votre espace personnel</p>
            </div>

            <form action="index.php" method="POST" class="login-form">
                <?= csrf_field() ?>
                <div class="input-group">
                    <label for="email">Adresse e-mail</label>
                    <input type="email" id="email" name="email" placeholder="exemple@entreprise.com" value="<?= h($_POST['email'] ?? '') ?>" required autofocus>
                </div>
                <div class="input-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" placeholder="Votre mot de passe" required>
                </div>
                <button type="submit">Se connecter</button>
            </form>

            <?php if (($cfg['mode'] ?? '') === 'demo') { ?>
            <div class="demo-hint">
                <strong>Mode démo</strong> (mot de passe : <code>demo1234</code>)
                <ul>
                    <li>Employé : aminata.sow@entreprise.com</li>
                    <li>Responsable : ibrahima.diop@entreprise.com</li>
                    <li>RH : khady.fall@entreprise.com</li>
                </ul>
            </div>
            <?php } ?>
        </div>
    </section>
</div>
<?php if ($erreur) { ?><div id="flash" data-type="error" data-msg="<?= h($erreur) ?>" hidden></div><?php } ?>
<script src="Scripts.js"></script>
</body>
</html>
