<?php
// ============================================================
// CONFIGURATION : le SEUL fichier à modifier pour passer en MySQL
// ============================================================
return [
    // 'demo'  : base SQLite locale créée automatiquement (aucune installation)
    // 'mysql' : votre base MySQL / phpMyAdmin (voir section mysql ci-dessous)
    'mode'  => 'demo',

    'mysql' => [
        'host' => 'localhost',
        'port' => 3306,
        'name' => 'WORKFLOW',
        'user' => 'root',
        'pass' => '',
    ],

    'sqlite' => ROOT . '/data/demo.sqlite',
    'debug'  => false,   // true : affiche le détail des erreurs de base de données
];
