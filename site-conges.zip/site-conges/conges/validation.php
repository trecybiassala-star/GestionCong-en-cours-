<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login(['Responsable', 'RH']);
$u = user(); $repo = repo();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $decision = ($_POST['decision'] ?? '') === 'APPROUVEE' ? 'APPROUVEE' : (($_POST['decision'] ?? '') === 'REFUSEE' ? 'REFUSEE' : '');
    $permis = array_map('intval', array_column($repo->aValider($u), 'demandeid'));   // contrôle d'accès côté serveur
    if ($decision === '' || !in_array($id, $permis, true)) flash('Demande introuvable ou hors de votre périmètre.', 'error');
    elseif ($repo->decide($id, $u['utilisateurid'], $decision, substr(trim($_POST['commentaire'] ?? ''), 0, 255)))
        flash("Demande n°$id " . ($decision === 'APPROUVEE' ? 'approuvée.' : 'refusée.'));
    else flash('Impossible de traiter cette demande (déjà traitée ?).', 'error');
    redirect('validation.php');
}

$liste = $repo->aValider($u);
$cible = (int)($_GET['id'] ?? 0);
layout_top('Validation des demandes', 'conges/validation.php');
?>
<section class="dashboard-panel reveal">
    <h2>Demandes en attente (<?= count($liste) ?>)</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>Employé</th><th>Type</th><th>Période</th><th>Jours</th><th>Motif</th><th>Décision</th></tr></thead>
        <tbody>
        <?php foreach ($liste as $d) { ?>
            <tr <?= (int)$d['demandeid'] === $cible ? 'class="ligne-cible"' : '' ?>>
                <td><?= h($d['nom'] . ' ' . $d['prenom']) ?></td><td><?= h($d['nomtype']) ?></td>
                <td><?= fdate($d['datedebut']) ?> → <?= fdate($d['datefin']) ?></td><td><?= (int)$d['nbjours'] ?></td><td><?= h($d['motif']) ?></td>
                <td><form method="POST" class="inline-form">
                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$d['demandeid'] ?>">
                    <input type="text" name="commentaire" maxlength="255" placeholder="Commentaire">
                    <button class="btn-sm btn-ok btn-validation" name="decision" value="APPROUVEE">Approuver</button>
                    <button class="btn-sm btn-ko btn-validation" name="decision" value="REFUSEE">Refuser</button>
                </form></td></tr>
        <?php } if (!$liste) { ?><tr><td colspan="6">Aucune demande à valider.</td></tr><?php } ?>
        </tbody>
    </table></div>
</section>
<?php layout_bottom(); ?>
