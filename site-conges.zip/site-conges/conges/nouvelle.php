<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login();
$u = user(); $repo = repo(); $types = $repo->types(); $err = [];
$v = ['type' => '', 'debut' => '', 'fin' => '', 'motif' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $v = ['type' => (int)($_POST['type'] ?? 0), 'debut' => $_POST['debut'] ?? '', 'fin' => $_POST['fin'] ?? '', 'motif' => trim($_POST['motif'] ?? '')];
    $date = fn($x) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $x) && strtotime($x) !== false;

    if (!in_array($v['type'], array_map('intval', array_column($types, 'typecongeid')), true)) $err[] = 'Type de congé invalide.';
    if (!$date($v['debut']) || !$date($v['fin'])) $err[] = 'Dates invalides.';
    elseif ($v['fin'] < $v['debut']) $err[] = 'La date de fin doit suivre la date de début.';
    elseif ($v['debut'] < date('Y-m-d')) $err[] = 'La date de début ne peut pas être passée.';
    if (strlen($v['motif']) > 255) $err[] = 'Le motif est trop long (255 caractères maximum).';

    if (!$err) {
        $jours = jours_ouvres($v['debut'], $v['fin']);
        $reste = $repo->restant($u['utilisateurid'], $v['type']);
        if ($jours < 1) $err[] = 'La période ne contient aucun jour ouvré.';
        elseif ($reste !== null && $jours > $reste) $err[] = "Solde insuffisant : $jours jour(s) demandé(s), $reste restant(s).";
        elseif ($repo->chevauche($u['utilisateurid'], $v['debut'], $v['fin'])) $err[] = 'Une autre demande existe déjà sur cette période.';
        else {
            $id = $repo->addDemande($u['utilisateurid'], $v['type'], $v['debut'], $v['fin'], $jours, $v['motif']);
            flash("Demande n°$id envoyée ($jours jour(s) ouvré(s)).");
            redirect('liste.php');
        }
    }
    $flashNow = (bool)$err;   // message d'erreur animé
}
layout_top('Nouvelle demande', 'conges/nouvelle.php');
if (!empty($flashNow)) { ?><div id="flash" data-type="error" data-msg="<?= h(implode(' ', $err)) ?>" hidden></div><?php } ?>

<section class="dashboard-panel reveal">
    <h2>Formulaire de demande</h2>
    <form method="POST" novalidate>
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="input-group"><label for="type">Type de congé</label>
                <select id="type" name="type" required>
                    <option value="">Choisir…</option>
                    <?php foreach ($types as $t) { ?><option value="<?= (int)$t['typecongeid'] ?>" <?= (int)$v['type'] === (int)$t['typecongeid'] ? 'selected' : '' ?>><?= h($t['nomtype']) ?></option><?php } ?>
                </select></div>
            <div class="input-group"><label for="debut">Date de début</label><input type="date" id="debut" name="debut" min="<?= date('Y-m-d') ?>" value="<?= h($v['debut']) ?>" required></div>
            <div class="input-group"><label for="fin">Date de fin</label><input type="date" id="fin" name="fin" min="<?= date('Y-m-d') ?>" value="<?= h($v['fin']) ?>" required></div>
        </div>
        <div class="input-group"><label for="motif">Motif</label><textarea id="motif" name="motif" maxlength="255" placeholder="Précisez le motif (facultatif)"><?= h($v['motif']) ?></textarea></div>
        <p id="duree" class="hint"></p>
        <button type="submit">Envoyer la demande</button>
    </form>
</section>
<?php layout_bottom(); ?>
