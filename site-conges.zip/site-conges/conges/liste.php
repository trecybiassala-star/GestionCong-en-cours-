<?php
require __DIR__ . '/../includes/bootstrap.php';
require_login();
$u = user();
$demandes = repo()->demandes('d.UtilisateurId = ?', [$u['utilisateurid']]);
layout_top('Mes demandes', 'conges/liste.php');
?>
<section class="dashboard-panel reveal">
    <h2>Historique de mes demandes</h2>
    <div class="table-wrap"><table>
        <thead><tr><th>N°</th><th>Type</th><th>Début</th><th>Fin</th><th>Jours</th><th>Motif</th><th>Statut</th></tr></thead>
        <tbody>
        <?php foreach ($demandes as $d) { ?>
            <tr><td><?= (int)$d['demandeid'] ?></td><td><?= h($d['nomtype']) ?></td><td><?= fdate($d['datedebut']) ?></td><td><?= fdate($d['datefin']) ?></td>
                <td><?= (int)$d['nbjours'] ?></td><td><?= h($d['motif']) ?></td><td><?= badge_statut($d['statut']) ?></td></tr>
        <?php } if (!$demandes) { ?><tr><td colspan="7">Aucune demande pour le moment.</td></tr><?php } ?>
        </tbody>
    </table></div>
    <p style="margin-top:20px"><a class="btn-treat" href="nouvelle.php">Nouvelle demande</a></p>
</section>
<?php layout_bottom(); ?>
